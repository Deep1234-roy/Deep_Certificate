package com.main;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.web.servlet.ModelAndView;

import com.main.controller.AdminController;
import com.main.pojo.Customer;

@SpringBootTest
class CitiusTechFoodCornerSystemApplicationTests {

	private AdminController adm;
	
	@BeforeEach
	public void setup() {
		System.out.println("Object has Created!!");
		adm = new AdminController();
	}
	
	@Test
	void contextLoads() {
	}

	@Test
	@DisplayName("Home Page Testing")
	public void testHome() {
		String actual  = adm.home();
		String expected = "home";
		assertThat(actual).isEqualTo(expected);
		
	}
	
	@Test
	@DisplayName("Customer Registration Page Testing")
	public void CustomerRegistrationTesting() {
		String actual = adm.CustomerReg();
		String expected = "CustomerRegistrationPage";
		assertThat(actual).isEqualTo(expected);
	}
	
	
	@AfterEach
	public void tearDown() {
		System.out.println("Object is Destroyed!!");
		adm=null;
	}
}
